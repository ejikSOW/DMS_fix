drop the contents of the a3_dms\scripts into your a3_dms\scripts folder and overwrite them

Note: if you have special missions (in config DMS_SpecialMissions) then you may need to do some work